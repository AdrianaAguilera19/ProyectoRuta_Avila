import React from 'react';

export default function RutaCard({ ruta }) {
  return (
    <div className="route-card">
      <div className="header">
        <img src={ruta.imagen} alt="icono" />
        <h2 className="text-31">{ruta.nombre}</h2>
        <p className="price">{ruta.precio}</p>
      </div>
      <div className="route-details">
        <span className="text-32">
          {ruta.dificultad} - {ruta.distancia} - {ruta.tiempo}
        </span>
        <div className="rating">
          <img src={ruta.rating} alt="estrella" />
        </div>
      </div>
    </div>
  );
}