import React from 'react';
import Titulo from './Titulo';
import Rutas from './Rutas';
import Mapa from './Mapa';
import './App.css';

export default function App() {
  return (
    <div className="rutas-homepage-1">
      <div className="rectangle-3-2"></div>
      <Titulo />
      <div className="flex-container">
        <Rutas />
        <Mapa />
      </div>
    </div>
  );
}